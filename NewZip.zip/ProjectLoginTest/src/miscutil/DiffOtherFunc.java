package miscutil;

public class DiffOtherFunc {

	public static boolean compareString(String str1,String str2) {

	    boolean res=false;
	    if (str1.equals(str2))
	        res=true;
	    else
	         res=false;

	     return res;
	  }
	
}
